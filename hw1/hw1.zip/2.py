# -*- coding: utf-8 -*-
"""
Created on Sat Dec  3 00:17:18 2022

@author: B11130038 王家宏
"""
print(format("年度","^10"),format("營業額","^15"),format("獲利率","^15"))
print(format(105,"^10"),format(1550000,"^15,"),format(0.0309,"15.2%"))
print(format(106,"^10"),format(2000000,"^15,"),format(0.0523,"15.2%"))
print(format(107,"^10"),format(2234000,"^15,"),format(0.0547,"15.2%"))