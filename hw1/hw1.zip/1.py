# -*- coding: utf-8 -*-
"""
Created on Sat Dec  3 00:11:39 2022

@author: B11130038 王家宏
"""

up=int(input("請輸入上底："))
down=int(input("請輸入下底："))
high=int(input("請輸入高："))
print("梯形面積為",float(up+down)*high/2)